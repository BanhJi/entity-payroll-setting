'use strict'

module.exports = {
  awsAccountId: '260206821052',
  region: 'ap-southeast-1'
}
